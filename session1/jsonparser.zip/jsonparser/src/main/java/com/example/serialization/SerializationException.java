package com.example.serialization;

public class SerializationException extends Exception {
    public SerializationException(String message) {
        super(message);
    }
}
